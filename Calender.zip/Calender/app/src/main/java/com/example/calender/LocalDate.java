package com.example.calender;

import java.time.format.DateTimeFormatter;

public class LocalDate {
    public static LocalDate now() {
        return null;
    }

    public String format(DateTimeFormatter formatter) {
        return null;
    }

    public LocalDate withDayOfMonth(int i) {
    }

    public com.android.build.gradle.internal.cxx.configure.SdkSourceProperties getDayOfWeek() {
    }

    public LocalDate minusMonths(int i) {
    }

    public void plusMonths(int i) {
    }
}
